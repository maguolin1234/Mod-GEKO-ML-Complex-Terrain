The "Bolund.grd", "Bolund_roughness.grd" and "Bolund.map" files contain the orography of
the Bolund hill. The map projection used for the coordinates is the UTM (Universal Transverse
Mercator) projection using the 6-degree longitudinal zone number 32 (UTM WGS84 zone 32). In
order to make coordinates more readable all coordinate values have been subtracted 
(694682.098; 6177441.825). "Bolund_roughness.grd" and "Bolund.map" contain information about
the surface roughness. Two values of roughness length have been used, z0=0.015m for land 
and z0=0.0003m for water.


"Bolund.grd" 
The Bolund topography with 0.25m resolution. It describes an area with SW/NE corners of 
(-98, -132)/(192, 118). The number of grid points are (1161,1001).
Surfer GRD-ASCII format:
Line	Content
1	DSAA for ASCII grid file
2	Number of grid points along the x-axis (columns) and y-axis (rows)
3	Minimum and maximum x-coordinate of the grid (west and east bounding coordinate)
4	Minimum and maximum y-coordinate of the grid (north and south bounding coordinate)
5	Minimum and maximum z-coordinate of the grid
6-n	z-values organized row-wise


"Bolund_roughness.grd" 
The Bolund roughness with 25cm resolution. z0=0.015m for land and z0=0.0003m for water.
Surfer GRD-ASCII format:
Line	Content
1	DSAA for ASCII grid file
2	Number of grid points along the x-axis (columns) and y-axis (rows)
3	Minimum and maximum x-coordinate of the grid (west and east bounding coordinate)
4	Minimum and maximum y-coordinate of the grid (north and south bounding coordinate)
5	Minimum and maximum z-coordinate of the grid
6-n	z0-values organized row-wise


"Bolund.map"
The file contains both the topography and surface roughness of Bolund. The map has 200
elevation contour lines and 1 roughness change line. It describes an area with SW/NE 
corners thus: (-68.5; -86.0)/(161.0; 62.0). Two values of roughness length have been 
used, z0=0.015m for land and z0=0.0003m for water. The format of the map file is similar
to the one used in WAsP.
Map-Format:
Four lines of irrelevant data
The following two steps is then repeated to the end of the file:
1. A height contour or a roughness change line is given:
	Height contour: 	elevation (Z) and number of points (n) in line: Z n
	Roughness change line: 	roughness lengths to the left (z0l) and right (z0r) side
				of the line, respectively, and number of points: z0l z0r n
2. On the following n lines the Cartesian coordinates (X,Y) of the points of the line are
   given in meters.


How to cite the data (planned to be released on 01/07/09) :
A. Bechmann, J. Berg, M.S. Courtney, H.E. J�rgensen, J. Mann and N.N.S�rensen. 
The Bolund Experiment: Overview and Background. 
Technical Report Ris�-R1658(EN), Ris� DTU, National Laboratory for Sustainable Energy 
Roskilde, Denmark, 2009.


Adress questions to:
Andreas Bechmann or N.N. S�rensen
Ris� DTU
National Laboratory for Sustainable Energy
Building 118, P.O. Box 49
DK-4000 Roskilde, Denmark
www.andh@risoe.dtu.dk 
www.nsqr@risoe.dtu.dk 

